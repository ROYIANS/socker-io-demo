# socker-io-demo
socker-io demo

## Quick Start

> npm install
> node index

Then view localhost:3000